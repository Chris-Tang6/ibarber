create definer = root@localhost trigger trigger_charge
    after insert
    on charge
    for each row
begin 
	update ibarber.vip v set v.wallet =v.wallet + new.money
	where v.id = new.id;
end;

